package com.Macate.APIRestaurante.DTOs;

public record TableDTO(Boolean availability, int chairs, String size) {
}
