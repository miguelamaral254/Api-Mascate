package com.Macate.APIRestaurante.DTOs;

public record CheckoutDTO(int tableID) {
}
