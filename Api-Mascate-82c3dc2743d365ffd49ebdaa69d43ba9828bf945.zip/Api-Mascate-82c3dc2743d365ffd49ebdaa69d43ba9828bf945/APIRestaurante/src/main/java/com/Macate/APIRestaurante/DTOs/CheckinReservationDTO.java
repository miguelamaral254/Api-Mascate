package com.Macate.APIRestaurante.DTOs;

public record CheckinReservationDTO(int id) {
}
