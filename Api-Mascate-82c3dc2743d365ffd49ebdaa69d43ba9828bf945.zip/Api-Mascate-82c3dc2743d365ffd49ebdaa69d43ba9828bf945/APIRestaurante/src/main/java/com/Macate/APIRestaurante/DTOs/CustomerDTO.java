package com.Macate.APIRestaurante.DTOs;

public record CustomerDTO(int customerName, String cpf, String phoneNumber) {
}
