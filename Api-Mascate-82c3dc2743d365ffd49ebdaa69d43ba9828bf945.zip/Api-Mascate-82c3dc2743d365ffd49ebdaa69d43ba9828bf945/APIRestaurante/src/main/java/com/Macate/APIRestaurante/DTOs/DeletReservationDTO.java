package com.Macate.APIRestaurante.DTOs;

public record DeletReservationDTO(int id) {
}
