package com.Macate.APIRestaurante.DTOs;

public record EmployeeDTO(int employee_id, String name, int reservations_made) {
}
